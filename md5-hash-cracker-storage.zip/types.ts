
export enum CrackStatus {
  CRACKING = 'Cracking...',
  FOUND = 'Found',
  NOT_FOUND = 'Not Found',
  ERROR = 'Error'
}

export interface HashResult {
  id: number;
  hash: string;
  plainText: string;
  status: CrackStatus;
}
