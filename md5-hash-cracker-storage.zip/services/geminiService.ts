
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const PROMPT = `
You are an expert system specialized in identifying common plain text strings from their corresponding MD5 hashes.
Your knowledge base includes a vast collection of common words, phrases, and passwords.
Your task is to take a given MD5 hash and return the original plain text string.

RULES:
1.  If you identify the plain text, return ONLY the plain text string and nothing else.
2.  If you cannot find a match in your knowledge base, or if you are uncertain, you MUST return the exact string 'NOT_FOUND'.
3.  Do not provide any explanations, apologies, or extra text. Your response must be either the found plain text or 'NOT_FOUND'.

Here is the hash:
`;

export const crackMd5Hash = async (hash: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `${PROMPT} ${hash}`,
      config: {
        temperature: 0, // Be deterministic
      },
    });

    const text = response.text.trim();
    
    if (!text) {
      return 'NOT_FOUND';
    }

    return text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to crack hash via Gemini API.");
  }
};
