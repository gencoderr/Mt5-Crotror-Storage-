
import React, { useState, useCallback } from 'react';
import { HashResult, CrackStatus } from './types';
import { crackMd5Hash } from './services/geminiService';
import InputForm from './components/InputForm';
import ResultsTable from './components/ResultsTable';
import FooterLog from './components/FooterLog';

const App: React.FC = () => {
  const [results, setResults] = useState<HashResult[]>([]);
  const [currentHash, setCurrentHash] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleCrackHash = useCallback(async () => {
    if (!currentHash || isLoading || currentHash.length !== 32 || !/^[a-f0-9]{32}$/i.test(currentHash)) {
        setError('Please enter a valid 32-character MD5 hash.');
        return;
    }
    
    setError(null);
    setIsLoading(true);

    const newResult: HashResult = {
      id: Date.now(),
      hash: currentHash,
      plainText: '',
      status: CrackStatus.CRACKING,
    };
    
    setResults(prev => [newResult, ...prev]);
    setCurrentHash('');

    try {
      const plainText = await crackMd5Hash(currentHash);
      setResults(prev => prev.map(r => 
        r.id === newResult.id
          ? {
              ...r,
              plainText: plainText === 'NOT_FOUND' ? '---' : plainText,
              status: plainText === 'NOT_FOUND' ? CrackStatus.NOT_FOUND : CrackStatus.FOUND,
            }
          : r
      ));
    } catch (err) {
      console.error('Error cracking hash:', err);
      setError('An error occurred while communicating with the AI. Please try again.');
      setResults(prev => prev.map(r =>
        r.id === newResult.id
          ? { ...r, status: CrackStatus.ERROR, plainText: 'Error' }
          : r
      ));
    } finally {
      setIsLoading(false);
    }
  }, [currentHash, isLoading]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-mono flex flex-col items-center p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-green-400 animate-pulse">MD5 Hash Cracker Storage</h1>
          <p className="text-gray-400 mt-2">Leveraging cloud-native AI to find plain text from MD5 hashes.</p>
        </header>

        <main className="bg-gray-800/50 rounded-lg shadow-2xl shadow-green-500/10 p-6 backdrop-blur-sm border border-green-500/20 mb-8">
          <InputForm
            currentHash={currentHash}
            setCurrentHash={setCurrentHash}
            handleCrackHash={handleCrackHash}
            isLoading={isLoading}
          />
          {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
        </main>
        
        <ResultsTable results={results} />

        <FooterLog />
      </div>
    </div>
  );
};

export default App;
