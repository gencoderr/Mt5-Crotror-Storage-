
import React from 'react';

interface InputFormProps {
  currentHash: string;
  setCurrentHash: (hash: string) => void;
  handleCrackHash: () => void;
  isLoading: boolean;
}

const InputForm: React.FC<InputFormProps> = ({ currentHash, setCurrentHash, handleCrackHash, isLoading }) => {
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleCrackHash();
  };
    
  return (
    <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-4">
      <div className="relative w-full">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
        <input
          type="text"
          value={currentHash}
          onChange={(e) => setCurrentHash(e.target.value)}
          placeholder="Enter MD5 hash (e.g., 8b1a9953c4611296a827abf8c47804d7)"
          className="w-full bg-gray-900 border border-gray-600 rounded-md py-3 pl-10 pr-4 text-green-300 focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition duration-200 placeholder-gray-500"
          disabled={isLoading}
        />
      </div>
      <button
        type="submit"
        disabled={isLoading || !currentHash}
        className="w-full sm:w-auto flex items-center justify-center px-6 py-3 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition duration-200"
      >
        {isLoading ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Cracking...
          </>
        ) : (
          'Crack Hash'
        )}
      </button>
    </form>
  );
};

export default InputForm;
