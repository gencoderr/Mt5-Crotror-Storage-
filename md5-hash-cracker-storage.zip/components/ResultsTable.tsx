
import React from 'react';
import { HashResult, CrackStatus } from '../types';

interface ResultsTableProps {
  results: HashResult[];
}

const getStatusColor = (status: CrackStatus) => {
  switch (status) {
    case CrackStatus.FOUND:
      return 'text-green-400';
    case CrackStatus.NOT_FOUND:
      return 'text-red-400';
    case CrackStatus.CRACKING:
        return 'text-yellow-400 animate-pulse';
    case CrackStatus.ERROR:
        return 'text-red-600';
    default:
      return 'text-gray-400';
  }
};

const ResultsTable: React.FC<ResultsTableProps> = ({ results }) => {
  if (results.length === 0) {
    return (
      <div className="text-center py-10 border-2 border-dashed border-gray-700 rounded-lg">
        <p className="text-gray-500">No hashes cracked yet. Results will appear here.</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto bg-gray-900/50 rounded-lg border border-gray-700/50">
      <table className="min-w-full divide-y divide-gray-700">
        <thead className="bg-gray-800/70">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
              Status
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
              Plain Text
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
              MD5 Hash
            </th>
          </tr>
        </thead>
        <tbody className="bg-gray-900/30 divide-y divide-gray-800">
          {results.map((result) => (
            <tr key={result.id} className="hover:bg-gray-800/50 transition-colors duration-200">
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`font-semibold ${getStatusColor(result.status)}`}>
                  {result.status}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-lg text-white">
                {result.plainText || '...'}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-gray-400">
                {result.hash}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ResultsTable;
