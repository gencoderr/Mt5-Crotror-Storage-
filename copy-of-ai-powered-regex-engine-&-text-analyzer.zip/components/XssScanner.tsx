import React, { useState } from 'react';
import { analyzeForXss } from '../services/geminiService';
import { XssAnalysisResponse, XssVulnerability } from '../types';

const LoadingSpinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const severityStyles: Record<XssVulnerability['severity'], { bg: string; text: string; border: string }> = {
    High: { bg: 'bg-red-900/50', text: 'text-red-300', border: 'border-red-500/50' },
    Medium: { bg: 'bg-orange-900/50', text: 'text-orange-300', border: 'border-orange-500/50' },
    Low: { bg: 'bg-yellow-900/50', text: 'text-yellow-300', border: 'border-yellow-500/50' },
};

const VulnerabilityCard: React.FC<{ vulnerability: XssVulnerability }> = ({ vulnerability }) => {
    const styles = severityStyles[vulnerability.severity] || severityStyles.Low;

    return (
        <div className={`p-4 rounded-lg border ${styles.border} ${styles.bg}`}>
            <div className="flex justify-between items-center mb-3">
                <h4 className={`text-lg font-bold ${styles.text}`}>Potential Vulnerability</h4>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${styles.bg} ${styles.text} border ${styles.border}`}>{vulnerability.severity}</span>
            </div>
            
            <div className="space-y-4">
                <div>
                    <h5 className="text-sm font-semibold text-slate-400 mb-1">Vulnerable Code</h5>
                    <pre className="bg-slate-900/70 p-2 rounded-md border border-slate-700 text-sm text-red-400 overflow-x-auto"><code>{vulnerability.vulnerableCode}</code></pre>
                </div>
                 <div>
                    <h5 className="text-sm font-semibold text-slate-400 mb-1">Explanation</h5>
                    <p className="text-slate-300 text-sm">{vulnerability.explanation}</p>
                </div>
                <div>
                    <h5 className="text-sm font-semibold text-slate-400 mb-1">Suggested Fix</h5>
                    <pre className="bg-slate-900/70 p-2 rounded-md border border-slate-700 text-sm text-green-400 overflow-x-auto"><code>{vulnerability.suggestion}</code></pre>
                </div>
            </div>
        </div>
    );
}

const XssScanner: React.FC = () => {
    const [codeSnippet, setCodeSnippet] = useState<string>('<div>Welcome, {{ username }}</div>\n<script>var q = window.location.search;</script>');
    const [analysis, setAnalysis] = useState<XssAnalysisResponse | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleAnalyze = async () => {
        if (!codeSnippet.trim()) {
            setError('Please provide a code snippet to analyze.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setAnalysis(null);
        try {
            const result = await analyzeForXss(codeSnippet);
            setAnalysis(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <section className="bg-slate-800/50 rounded-lg shadow-2xl shadow-amber-500/10 p-6 backdrop-blur-sm border border-amber-500/20 mt-8" aria-labelledby="xss-scanner-heading">
            <h2 id="xss-scanner-heading" className="text-2xl font-bold text-amber-400 mb-4">XSS Vulnerability Scanner</h2>
            <p className="text-slate-400 mb-4">Analyze text or code snippets for potential Cross-Site Scripting (XSS) vulnerabilities.</p>

            <div className="space-y-4">
                <textarea
                    value={codeSnippet}
                    onChange={(e) => setCodeSnippet(e.target.value)}
                    placeholder="<script>alert('xss')</script>"
                    className="w-full h-32 bg-slate-900/70 border border-slate-700/50 rounded-lg p-4 text-slate-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500 resize-y font-mono text-sm"
                    spellCheck="false"
                    aria-label="Code snippet for XSS analysis"
                />
                <div className="flex justify-end">
                    <button
                        onClick={handleAnalyze}
                        disabled={isLoading}
                        className="flex items-center justify-center px-6 py-2 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition duration-200"
                    >
                        {isLoading && <LoadingSpinner />}
                        {isLoading ? 'Scanning...' : 'Scan for XSS'}
                    </button>
                </div>
            </div>

            {error && <p className="text-red-400 mt-4 bg-red-900/50 p-3 rounded-md border border-red-500/50">{error}</p>}

            {analysis && (
                <div className="mt-6 border-t border-slate-700 pt-6 space-y-4" aria-live="polite">
                   <h3 className="text-lg font-semibold text-green-400">{analysis.summary}</h3>
                   {analysis.vulnerabilities.length > 0 ? (
                       analysis.vulnerabilities.map((vuln, index) => <VulnerabilityCard key={index} vulnerability={vuln} />)
                   ) : (
                       <div className="text-center p-4 bg-green-900/50 border border-green-500/50 rounded-lg">
                           <p className="text-green-300">No potential XSS vulnerabilities were found.</p>
                       </div>
                   )}
                </div>
            )}
        </section>
    );
};

export default XssScanner;