import React, { useState } from 'react';
import { generateTextFromTemplate } from '../services/geminiService';
import { TemplateVariable } from '../types';

const LoadingSpinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const StringTheoryGenerator: React.FC = () => {
    const [template, setTemplate] = useState<string>('Write a short, friendly welcome email to {{name}} introducing them to our product, {{product}}.');
    const [variables, setVariables] = useState<TemplateVariable[]>([
        { id: crypto.randomUUID(), key: 'name', value: 'Alex' },
        { id: crypto.randomUUID(), key: 'product', value: 'The AI Regex Engine' }
    ]);
    const [generatedText, setGeneratedText] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleVariableChange = (id: string, field: 'key' | 'value', value: string) => {
        setVariables(vars => vars.map(v => v.id === id ? { ...v, [field]: value } : v));
    };

    const addVariable = () => {
        setVariables(vars => [...vars, { id: crypto.randomUUID(), key: '', value: '' }]);
    };

    const removeVariable = (id: string) => {
        setVariables(vars => vars.filter(v => v.id !== id));
    };

    const handleGenerate = async () => {
        setIsLoading(true);
        setError(null);
        setGeneratedText('');

        try {
            const varsObject = variables.reduce((acc, v) => {
                if (v.key) acc[v.key] = v.value;
                return acc;
            }, {} as Record<string, string>);

            const result = await generateTextFromTemplate(template, varsObject);
            setGeneratedText(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <section className="bg-slate-800/50 rounded-lg shadow-2xl shadow-amber-500/10 p-6 backdrop-blur-sm border border-amber-500/20 mt-8" aria-labelledby="string-theory-heading">
            <h2 id="string-theory-heading" className="text-2xl font-bold text-amber-400 mb-4">String Theory: AI Text Generator</h2>
            <p className="text-slate-400 mb-6">Create dynamic text using a template and variables. The AI will intelligently weave them together for you.</p>

            <div className="space-y-6">
                <div>
                    <label htmlFor="template" className="block text-sm font-medium text-slate-400 mb-2">1. Template / Prompt</label>
                    <textarea
                        id="template"
                        value={template}
                        onChange={(e) => setTemplate(e.target.value)}
                        placeholder="Write a marketing email about {{product}} for {{target_audience}}."
                        className="w-full h-28 bg-slate-900/70 border border-slate-700/50 rounded-lg p-4 text-slate-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500 resize-y font-mono text-sm"
                        spellCheck="false"
                    />
                </div>
                <div>
                    <h3 className="text-sm font-medium text-slate-400 mb-2">2. Variables</h3>
                    <div className="space-y-2">
                        {variables.map((variable, index) => (
                            <div key={variable.id} className="flex items-center gap-2">
                                <input
                                    type="text"
                                    value={variable.key}
                                    onChange={(e) => handleVariableChange(variable.id, 'key', e.target.value)}
                                    placeholder={`Key ${index + 1}`}
                                    className="flex-grow bg-slate-900 border border-slate-600 rounded-md py-2 px-3 text-amber-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500"
                                    aria-label={`Variable key ${index + 1}`}
                                />
                                <input
                                    type="text"
                                    value={variable.value}
                                    onChange={(e) => handleVariableChange(variable.id, 'value', e.target.value)}
                                    placeholder={`Value ${index + 1}`}
                                    className="flex-grow bg-slate-900 border border-slate-600 rounded-md py-2 px-3 text-amber-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500"
                                    aria-label={`Variable value ${index + 1}`}
                                />
                                <button onClick={() => removeVariable(variable.id)} className="p-2 text-slate-500 hover:text-red-400 transition-colors" aria-label={`Remove variable ${index + 1}`}>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                                    </svg>
                                </button>
                            </div>
                        ))}
                    </div>
                     <button onClick={addVariable} className="mt-2 text-sm text-green-400 hover:text-green-300 transition-colors flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                           <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-11a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V7z" clipRule="evenodd" />
                        </svg>
                        Add Variable
                    </button>
                </div>

                <div className="flex justify-center pt-2">
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading}
                        className="w-full sm:w-auto flex items-center justify-center px-8 py-3 bg-amber-600 text-slate-900 font-bold rounded-md hover:bg-amber-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition duration-200 text-lg"
                    >
                        {isLoading && <LoadingSpinner />}
                        {isLoading ? 'Generating...' : 'Generate Text'}
                    </button>
                </div>
            </div>

            {error && <p className="text-red-400 mt-4 bg-red-900/50 p-3 rounded-md border border-red-500/50">{error}</p>}
            
            {generatedText && (
                <div className="mt-6 border-t border-slate-700 pt-6" aria-live="polite">
                     <h3 className="text-lg font-semibold text-green-400 mb-2">Generated Output</h3>
                     <div className="bg-slate-900/70 p-4 rounded-md border border-slate-700">
                        <pre className="whitespace-pre-wrap break-words font-sans text-slate-300">{generatedText}</pre>
                     </div>
                </div>
            )}
        </section>
    );
};

export default StringTheoryGenerator;
