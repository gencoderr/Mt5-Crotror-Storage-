import React from 'react';

interface SourceEditorProps {
  sourceText: string;
  setSourceText: (value: string) => void;
}

const SourceEditor: React.FC<SourceEditorProps> = ({ sourceText, setSourceText }) => {
  return (
    <div className="h-full flex flex-col">
        <h2 className="text-lg font-bold text-amber-400 mb-2">Source Text</h2>
        <textarea
            value={sourceText}
            onChange={(e) => setSourceText(e.target.value)}
            placeholder="Paste your text here to be analyzed..."
            className="flex-grow w-full bg-slate-800/50 border border-slate-700/50 rounded-lg p-4 text-slate-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500 resize-none font-mono text-sm"
            spellCheck="false"
        />
    </div>
  );
};

export default SourceEditor;
