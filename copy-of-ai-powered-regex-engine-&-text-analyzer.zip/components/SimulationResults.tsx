import React, { useState } from 'react';
import { AnalysisStats, RegexMatch } from '../types';
import ReportModal from './ReportModal';

interface OutputPanelsProps {
    stats: AnalysisStats | null;
    matches: RegexMatch[];
    transformedText: string;
    regexPattern: string;
    replacementString: string;
}

const OutputPanels: React.FC<OutputPanelsProps> = ({ stats, matches, transformedText, regexPattern, replacementString }) => {
    const [isReportModalOpen, setIsReportModalOpen] = useState(false);

    if (!stats) {
        return (
            <div className="h-full flex items-center justify-center p-6 bg-slate-800/30 rounded-lg border-2 border-dashed border-slate-700">
                <p className="text-slate-500">Analysis results will be displayed here.</p>
            </div>
        );
    }
    
    return (
        <>
            <div className="space-y-6">
                {/* Stats Panel */}
                <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="text-lg font-bold text-amber-400">Analysis Stats</h3>
                        <button
                          onClick={() => setIsReportModalOpen(true)}
                          className="flex items-center gap-2 text-sm text-cyan-400 hover:text-cyan-300 transition-colors disabled:text-slate-600 disabled:cursor-not-allowed"
                          disabled={!stats}
                          aria-label="Generate analysis report"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
                                <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clipRule="evenodd" />
                            </svg>
                            Generate Report
                        </button>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                            <p className="text-sm text-slate-400">Matches Found</p>
                            <p className="text-2xl font-semibold text-green-400">{stats.matchCount}</p>
                        </div>
                        <div>
                            <p className="text-sm text-slate-400">Characters</p>
                            <p className="text-2xl font-semibold">{stats.charactersAnalyzed.toLocaleString()}</p>
                        </div>
                        <div>
                            <p className="text-sm text-slate-400">Exec. Time</p>
                            <p className="text-2xl font-semibold">{stats.executionTime.toFixed(2)}ms</p>
                        </div>
                    </div>
                </div>

                {/* Transformed Output Panel */}
                <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
                    <h3 className="text-lg font-bold text-amber-400 mb-2">Transformed Output</h3>
                     <textarea
                        readOnly
                        value={transformedText}
                        className="w-full h-48 bg-slate-900/70 border border-slate-700 rounded-md p-2 text-slate-300 resize-none font-mono text-sm focus:outline-none"
                        placeholder="Output after replacement..."
                    />
                </div>
                
                {/* Match List Panel */}
                 <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
                    <h3 className="text-lg font-bold text-amber-400 mb-2">Match List ({matches.length})</h3>
                    <div className="overflow-y-auto max-h-48 bg-slate-900/70 border border-slate-700 rounded-md p-2">
                        {matches.length > 0 ? (
                            <ul className="divide-y divide-slate-700">
                               {matches.map((match, i) => (
                                    <li key={i} className="p-2 flex justify-between items-center text-sm">
                                        <span className="text-green-400 break-all">{`'${match.value}'`}</span>
                                        <span className="text-slate-500 ml-4">index: {match.index}</span>
                                    </li>
                               ))}
                            </ul>
                        ) : (
                            <p className="text-slate-500 text-center p-4">No matches found.</p>
                        )}
                    </div>
                </div>
            </div>
            <ReportModal
                isOpen={isReportModalOpen}
                onClose={() => setIsReportModalOpen(false)}
                stats={stats}
                matches={matches}
                transformedText={transformedText}
                regexPattern={regexPattern}
                replacementString={replacementString}
            />
        </>
    );
};

export default OutputPanels;