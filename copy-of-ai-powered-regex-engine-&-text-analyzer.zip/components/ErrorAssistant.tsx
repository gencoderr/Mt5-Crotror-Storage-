import React, { useState } from 'react';
import { analyzeErrorLog } from '../services/geminiService';
import { ErrorAnalysisResponse } from '../types';

const LoadingSpinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const ErrorAssistant: React.FC = () => {
    const [errorLog, setErrorLog] = useState<string>('');
    const [analysis, setAnalysis] = useState<ErrorAnalysisResponse | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleAnalyze = async () => {
        if (!errorLog.trim()) {
            setError('Please paste an error message or log to analyze.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setAnalysis(null);
        try {
            const result = await analyzeErrorLog(errorLog);
            setAnalysis(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <section className="bg-slate-800/50 rounded-lg shadow-2xl shadow-amber-500/10 p-6 backdrop-blur-sm border border-amber-500/20 mt-8" aria-labelledby="error-assistant-heading">
            <h2 id="error-assistant-heading" className="text-2xl font-bold text-amber-400 mb-4">AI Error Assistant</h2>
            <p className="text-slate-400 mb-4">Paste a technical error message or log snippet, and the AI will provide an explanation and potential solutions.</p>

            <div className="space-y-4">
                <textarea
                    value={errorLog}
                    onChange={(e) => setErrorLog(e.target.value)}
                    placeholder="e.g., TypeError: Cannot read properties of undefined (reading 'map')"
                    className="w-full h-32 bg-slate-900/70 border border-slate-700/50 rounded-lg p-4 text-slate-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500 resize-y font-mono text-sm"
                    spellCheck="false"
                    aria-label="Error message or log snippet to be analyzed"
                />
                <div className="flex justify-end">
                    <button
                        onClick={handleAnalyze}
                        disabled={isLoading}
                        className="flex items-center justify-center px-6 py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition duration-200"
                    >
                        {isLoading && <LoadingSpinner />}
                        {isLoading ? 'Analyzing...' : 'Analyze Error'}
                    </button>
                </div>
            </div>

            {error && <p className="text-red-400 mt-4 bg-red-900/50 p-3 rounded-md border border-red-500/50">{error}</p>}

            {analysis && (
                <div className="mt-6 border-t border-slate-700 pt-6 space-y-6" aria-live="polite">
                    <div>
                        <h3 className="text-lg font-semibold text-green-400 mb-2">Summary</h3>
                        <p className="text-slate-300 whitespace-pre-wrap">{analysis.summary}</p>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-yellow-400 mb-2">Potential Causes</h3>
                        <ul className="list-disc list-inside space-y-1 text-slate-300">
                            {analysis.causes.map((cause, index) => <li key={index}>{cause}</li>)}
                        </ul>
                    </div>
                    <div>
                        <h3 className="text-lg font-semibold text-cyan-400 mb-2">Suggested Solution</h3>
                        <div className="bg-slate-900/70 p-4 rounded-md border border-slate-700">
                           <pre className="whitespace-pre-wrap break-words font-sans text-slate-300">{analysis.solution}</pre>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ErrorAssistant;
