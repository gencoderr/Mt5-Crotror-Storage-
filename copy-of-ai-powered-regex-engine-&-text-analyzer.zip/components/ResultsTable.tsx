import React from 'react';
import { StockDataPoint } from '../types';

interface ResultsTableProps {
  data: StockDataPoint[];
}

const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(amount);
};

const formatVolume = (volume: number) => {
    return new Intl.NumberFormat('en-US', { notation: 'compact', compactDisplay: 'short' }).format(volume);
};


const ResultsTable: React.FC<ResultsTableProps> = ({ data }) => {
  if (data.length === 0) {
    return null;
  }

  return (
    <div className="mt-2">
       <div className="overflow-y-auto max-h-[40vh] bg-zinc-900/50 rounded-lg border border-zinc-700/50">
        <table className="min-w-full divide-y divide-zinc-700">
          <thead className="bg-zinc-800/70 sticky top-0 z-10 backdrop-blur-sm">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Date</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Open</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">High</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Low</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Close</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Volume</th>
            </tr>
          </thead>
          <tbody className="bg-zinc-900/30 divide-y divide-zinc-800">
            {data.map((row) => (
              <tr key={row.date} className="hover:bg-zinc-800/50 transition-colors duration-200">
                <td className="px-6 py-4 whitespace-nowrap text-gray-300">{row.date}</td>
                <td className="px-6 py-4 whitespace-nowrap text-gray-300">{formatCurrency(row.open)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-green-400">{formatCurrency(row.high)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-red-400">{formatCurrency(row.low)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-cyan-300 font-bold">{formatCurrency(row.close)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-gray-300">{formatVolume(row.volume)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ResultsTable;