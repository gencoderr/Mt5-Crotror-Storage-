import React from 'react';
import { AnalysisStats, RegexMatch } from '../types';

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: AnalysisStats | null;
  matches: RegexMatch[];
  transformedText: string;
  regexPattern: string;
  replacementString: string;
}

const ReportSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="report-section">
    <h3 className="text-xl font-bold text-amber-400 mb-3 border-b-2 border-slate-700 pb-2">{title}</h3>
    {children}
  </div>
);

const ReportModal: React.FC<ReportModalProps> = ({ isOpen, onClose, stats, matches, transformedText, regexPattern, replacementString }) => {
  if (!isOpen || !stats) return null;

  const handlePrint = () => {
    window.print();
  };

  const reportDate = new Date().toLocaleString();

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center p-4 print:hidden"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="report-title"
    >
      <div
        id="report-content"
        className="bg-slate-900 text-slate-300 font-mono rounded-lg shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col border border-amber-500/30"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex justify-between items-center p-4 border-b border-slate-700">
          <h2 id="report-title" className="text-2xl font-bold text-amber-400">Text Analysis Report</h2>
          <div className="flex gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-cyan-600 text-white font-semibold rounded-md hover:bg-cyan-700 transition duration-200 flex items-center gap-2"
              aria-label="Print report"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5 4v3H4a2 2 0 00-2 2v6a2 2 0 002 2h12a2 2 0 002-2V9a2 2 0 00-2-2h-1V4a2 2 0 00-2-2H7a2 2 0 00-2 2zm8 0H7v3h6V4zm0 8H7v4h6v-4z" clipRule="evenodd" />
              </svg>
              Print
            </button>
            <button
              onClick={onClose}
              className="px-3 py-2 bg-slate-700 text-slate-300 font-semibold rounded-md hover:bg-slate-600 transition duration-200"
              aria-label="Close report modal"
            >
              &times;
            </button>
          </div>
        </header>
        <main className="p-6 overflow-y-auto space-y-6">
          <p className="text-sm text-slate-500">Generated on: {reportDate}</p>
          
          <ReportSection title="Analysis Statistics">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-sm text-slate-400">Matches Found</p>
                <p className="text-3xl font-semibold text-green-400">{stats.matchCount}</p>
              </div>
              <div>
                <p className="text-sm text-slate-400">Characters</p>
                <p className="text-3xl font-semibold">{stats.charactersAnalyzed.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-slate-400">Exec. Time</p>
                <p className="text-3xl font-semibold">{stats.executionTime.toFixed(2)}ms</p>
              </div>
            </div>
          </ReportSection>

          <ReportSection title="Pattern Details">
            <div className="space-y-2">
              <div>
                <p className="text-slate-400">Regex Pattern:</p>
                <code className="block bg-slate-800 p-2 rounded-md text-amber-300 text-sm break-all">{regexPattern}</code>
              </div>
              <div>
                <p className="text-slate-400">Replacement String:</p>
                <code className="block bg-slate-800 p-2 rounded-md text-amber-300 text-sm break-all">{replacementString || '(none)'}</code>
              </div>
            </div>
          </ReportSection>

          <ReportSection title="Transformed Output">
             <pre className="w-full h-48 bg-slate-800 border border-slate-700 rounded-md p-2 text-slate-300 overflow-auto text-sm whitespace-pre-wrap break-words">{transformedText}</pre>
          </ReportSection>

          <ReportSection title={`Match List (${matches.length})`}>
             <div className="overflow-y-auto max-h-60 bg-slate-800 border border-slate-700 rounded-md p-2">
                {matches.length > 0 ? (
                    <ul className="divide-y divide-slate-700/50">
                       {matches.map((match, i) => (
                            <li key={i} className="p-2 flex justify-between items-center text-sm">
                                <span className="text-green-400 break-all">{`'${match.value}'`}</span>
                                <span className="text-slate-500 ml-4">index: {match.index}</span>
                            </li>
                       ))}
                    </ul>
                ) : (
                    <p className="text-slate-500 text-center p-4">No matches found.</p>
                )}
             </div>
          </ReportSection>
        </main>
      </div>
    </div>
  );
};

export default ReportModal;
