import React, { useState } from 'react';
import { generatePostgresCode } from '../services/geminiService';

const LoadingSpinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const languages = {
    'Raw SQL': 'Raw SQL',
    'Node.js (node-postgres)': 'Node.js (node-postgres)',
    'Python (psycopg2)': 'Python (psycopg2)',
};

const PostgresCodeGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState<string>('Select all users from the "customers" table where the city is London.');
    const [language, setLanguage] = useState<string>(languages['Node.js (node-postgres)']);
    const [generatedCode, setGeneratedCode] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [copySuccess, setCopySuccess] = useState<string>('');

    const handleGenerate = async () => {
        if (!prompt.trim()) {
            setError('Please provide a description of the code you want to generate.');
            return;
        }
        setIsLoading(true);
        setError(null);
        setGeneratedCode('');
        setCopySuccess('');
        try {
            const result = await generatePostgresCode(prompt, language);
            setGeneratedCode(result);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleCopy = () => {
        if (generatedCode) {
            navigator.clipboard.writeText(generatedCode).then(() => {
                setCopySuccess('Copied!');
                setTimeout(() => setCopySuccess(''), 2000);
            }, (err) => {
                setCopySuccess('Failed to copy!');
                console.error('Could not copy text: ', err);
            });
        }
    };

    return (
        <section className="bg-slate-800/50 rounded-lg shadow-2xl shadow-amber-500/10 p-6 backdrop-blur-sm border border-amber-500/20 mt-8" aria-labelledby="postgres-code-generator-heading">
            <h2 id="postgres-code-generator-heading" className="text-2xl font-bold text-amber-400 mb-4">AI PostgreSQL Code Generator</h2>
            <p className="text-slate-400 mb-6">Describe a database task. The AI will generate secure, production-ready code to prevent SQL injection.</p>

            <div className="space-y-4">
                <div>
                    <label htmlFor="code-prompt" className="block text-sm font-medium text-slate-400 mb-2">1. Describe the task</label>
                    <textarea
                        id="code-prompt"
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="e.g., Create a user table with id, name, and email"
                        className="w-full h-24 bg-slate-900/70 border border-slate-700/50 rounded-lg p-4 text-slate-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500 resize-y font-mono text-sm"
                        spellCheck="false"
                    />
                </div>

                <div>
                    <label htmlFor="language-select" className="block text-sm font-medium text-slate-400 mb-2">2. Choose Language/Library</label>
                    <select
                        id="language-select"
                        value={language}
                        onChange={(e) => setLanguage(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-600 rounded-md py-2 px-3 text-amber-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200"
                    >
                        {Object.entries(languages).map(([key, value]) => (
                            <option key={key} value={value}>{key}</option>
                        ))}
                    </select>
                </div>
                
                <div className="flex justify-end">
                    <button
                        onClick={handleGenerate}
                        disabled={isLoading}
                        className="flex items-center justify-center px-6 py-2 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition duration-200"
                    >
                        {isLoading && <LoadingSpinner />}
                        {isLoading ? 'Generating...' : 'Generate Code'}
                    </button>
                </div>
            </div>

            {error && <p className="text-red-400 mt-4 bg-red-900/50 p-3 rounded-md border border-red-500/50">{error}</p>}

            {generatedCode && (
                <div className="mt-6 border-t border-slate-700 pt-6" aria-live="polite">
                     <div className="flex justify-between items-center mb-2">
                        <h3 className="text-lg font-semibold text-green-400">Generated Code</h3>
                        <button
                            onClick={handleCopy}
                            className="flex items-center gap-2 text-sm text-cyan-400 hover:text-cyan-300 transition-colors disabled:text-slate-600"
                            disabled={!generatedCode}
                        >
                            {copySuccess ? copySuccess : (
                                <>
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                        <path d="M7 9a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H9a2 2 0 01-2-2V9z" />
                                        <path d="M4 3a2 2 0 012-2h6a2 2 0 012 2v6a2 2 0 01-2 2H6a2 2 0 01-2-2V3z" />
                                    </svg>
                                    Copy
                                </>
                            )}
                        </button>
                     </div>
                     <div className="bg-slate-900/70 p-4 rounded-md border border-slate-700">
                        <pre className="whitespace-pre-wrap break-words font-mono text-sm text-slate-300"><code>{generatedCode}</code></pre>
                     </div>
                </div>
            )}
        </section>
    );
};

export default PostgresCodeGenerator;
