export interface AnalysisStats {
  matchCount: number;
  executionTime: number; // in ms
  charactersAnalyzed: number;
}

export interface RegexMatch {
  value: string;
  index: number;
}

export interface ErrorAnalysisResponse {
  summary: string;
  causes: string[];
  solution: string;
}

export interface TemplateVariable {
  id: string;
  key: string;
  value: string;
}

export interface XssVulnerability {
  vulnerableCode: string;
  explanation: string;
  suggestion: string;
  severity: 'High' | 'Medium' | 'Low';
}

export interface XssAnalysisResponse {
  summary: string;
  vulnerabilities: XssVulnerability[];
}

export interface StockDataPoint {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  rsi?: number | null;
  lips?: number | null;
  teeth?: number | null;
  jaw?: number | null;
}

export interface SimulationResult {
  initialCapital: number;
  finalCapital: number;
  profitOrLoss: number;
  profitOrLossPercent: number;
  trades: number;
}