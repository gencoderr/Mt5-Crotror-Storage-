import { GoogleGenAI, Type } from "@google/genai";
import { ErrorAnalysisResponse, XssAnalysisResponse } from "../types";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    pattern: { 
      type: Type.STRING, 
      description: 'The generated regular expression pattern string, formatted for JavaScript RegExp constructor. Do not include leading/trailing slashes or flags.' 
    },
  },
  required: ['pattern'],
};

export const suggestRegexPattern = async (description: string): Promise<string> => {
  const prompt = `
    You are an expert in regular expressions.
    Based on the following user description, generate a single, valid JavaScript regular expression pattern.
    The pattern should accurately match what the user is asking for.
    Only return the pattern string itself, without any slashes or flags.

    User description: "${description}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.2,
      },
    });

    const jsonString = response.text.trim();
    if (!jsonString) {
        throw new Error("AI returned empty response.");
    }
    
    const data = JSON.parse(jsonString);

    if (!data.pattern || typeof data.pattern !== 'string') {
        throw new Error("Invalid regex pattern format received from AI.");
    }

    return data.pattern;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get regex suggestion from AI. Please try a different description.");
  }
};

const errorAnalysisSchema = {
  type: Type.OBJECT,
  properties: {
    summary: { 
      type: Type.STRING, 
      description: 'A brief, one or two sentence summary of what the error means.' 
    },
    causes: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'A list of likely causes for the error. Provide at least two potential causes.'
    },
    solution: {
      type: Type.STRING,
      description: 'A detailed, step-by-step solution to fix the error. Use markdown for any code snippets, like ```javascript\n// code here\n```.'
    }
  },
  required: ['summary', 'causes', 'solution'],
};


export const analyzeErrorLog = async (log: string): Promise<ErrorAnalysisResponse> => {
    const prompt = `
      You are a senior software engineer and an expert in debugging.
      A user has provided the following error message or log snippet.
      Analyze it and provide a clear, helpful response.

      Error/Log:
      ---
      ${log}
      ---

      Your response must be a JSON object with a summary of the error, a list of potential causes, and a suggested solution.
    `;
  
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: errorAnalysisSchema,
          temperature: 0.3,
        },
      });
  
      const jsonString = response.text.trim();
      if (!jsonString) {
          throw new Error("AI returned empty response.");
      }
      
      const data = JSON.parse(jsonString);
  
      if (!data.summary || !data.causes || !data.solution) {
          throw new Error("Invalid analysis format received from AI.");
      }
  
      return data as ErrorAnalysisResponse;
    } catch (error) {
      console.error("Error calling Gemini API for error analysis:", error);
      throw new Error("Failed to get error analysis from AI. The error might be too complex or the service is busy.");
    }
  };

export const generateTextFromTemplate = async (template: string, variables: Record<string, string>): Promise<string> => {
  const variablesString = Object.entries(variables)
    .map(([key, value]) => `- ${key}: ${value}`)
    .join('\n');

  const prompt = `
    You are a helpful AI assistant specialized in generating text from templates.
    A user has provided a template and a set of variables.
    Your task is to use the variables to fill in the template and generate a complete text.
    Be creative but stay true to the user's template and context.

    Template:
    ---
    ${template}
    ---

    Variables:
    ---
    ${variablesString}
    ---

    Generated Text:
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        temperature: 0.7,
      },
    });

    const text = response.text;
    if (!text) {
        throw new Error("AI returned empty response.");
    }
    
    return text;
  } catch (error) {
    console.error("Error calling Gemini API for text generation:", error);
    throw new Error("Failed to generate text from AI. Please check your template and try again.");
  }
};

const xssVulnerabilitySchema = {
  type: Type.OBJECT,
  properties: {
    vulnerableCode: {
      type: Type.STRING,
      description: "The exact line or snippet of code that is vulnerable."
    },
    explanation: {
      type: Type.STRING,
      description: "A clear explanation of why this code is a potential XSS vulnerability."
    },
    suggestion: {
      type: Type.STRING,
      description: "A code snippet or description of how to fix the vulnerability (e.g., proper escaping or sanitization)."
    },
    severity: {
      type: Type.STRING,
      description: "The severity of the vulnerability: 'High', 'Medium', or 'Low'."
    }
  },
  required: ['vulnerableCode', 'explanation', 'suggestion', 'severity']
};

const xssAnalysisSchema = {
    type: Type.OBJECT,
    properties: {
        summary: {
            type: Type.STRING,
            description: "A brief, one-sentence summary of the findings. For example, 'Three potential XSS vulnerabilities were found.' or 'No direct XSS vulnerabilities were found in the provided snippet.'"
        },
        vulnerabilities: {
            type: Type.ARRAY,
            items: xssVulnerabilitySchema,
            description: "A list of all potential XSS vulnerabilities found in the text. If none are found, this should be an empty array."
        }
    },
    required: ['summary', 'vulnerabilities']
};


export const analyzeForXss = async (codeSnippet: string): Promise<XssAnalysisResponse> => {
  const prompt = `
    You are a senior cybersecurity analyst specializing in web application security.
    Your task is to analyze the following text or code snippet for potential Cross-Site Scripting (XSS) vulnerabilities.
    Identify any instances where user input is unsanitized and rendered directly into the output, or other common XSS patterns.
    For each vulnerability found, provide the vulnerable code, an explanation, a suggested fix, and a severity level.
    If no vulnerabilities are found, return a summary stating that and an empty vulnerabilities array.

    Code Snippet to analyze:
    ---
    ${codeSnippet}
    ---

    Your response must be a JSON object conforming to the specified schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: xssAnalysisSchema,
        temperature: 0.1,
      },
    });

    const jsonString = response.text.trim();
    if (!jsonString) {
        throw new Error("AI returned empty response.");
    }
    
    const data = JSON.parse(jsonString);

    if (!data.summary || !data.vulnerabilities) {
        throw new Error("Invalid XSS analysis format received from AI.");
    }

    return data as XssAnalysisResponse;
  } catch (error) {
    console.error("Error calling Gemini API for XSS analysis:", error);
    throw new Error("Failed to get XSS analysis from AI. The snippet might be too complex or the service is busy.");
  }
};

export const generatePostgresCode = async (description: string, language: string): Promise<string> => {
    const prompt = `
      You are an expert software developer with a specialization in database security.
      A user wants to generate a code snippet for interacting with a PostgreSQL database.
      Your most important task is to generate code that is secure against SQL injection by using parameterized queries (prepared statements).
      Do not ever use string concatenation or interpolation to build queries with user input.
  
      User's request: "${description}"
      Target language/library: "${language}"
  
      Generate only the code snippet requested. Do not include any explanatory text before or after the code block.
    `;
  
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          temperature: 0.2,
        },
      });
  
      const text = response.text;
      if (!text) {
          throw new Error("AI returned empty response.");
      }
      
      const codeBlockRegex = /```(?:\w*\n)?([\s\S]*?)```/;
      const match = text.match(codeBlockRegex);
      if (match && match[1]) {
        return match[1].trim();
      }
  
      return text.trim();
    } catch (error) {
      console.error("Error calling Gemini API for PostgreSQL code generation:", error);
      throw new Error("Failed to generate code from AI. Please check your prompt and try again.");
    }
  };