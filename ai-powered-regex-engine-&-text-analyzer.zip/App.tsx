import React, { useState, useCallback } from 'react';
import { AnalysisStats, RegexMatch } from './types';
import { suggestRegexPattern } from './services/geminiService';
import ControlPanel from './components/InputForm';
import SourceEditor from './components/RSIChart';
import OutputPanels from './components/SimulationResults';
import FooterLog from './components/FooterLog';

const initialSourceText = `
# R-Style Comment: Sample Log File Analysis
# This text contains various data formats to test regex patterns.

[2024-08-21 10:05:30] INFO: User 'alex_j' logged in from IP 192.168.1.101. Session ID: sid-axb123-xyz789.
[2024-08-21 10:07:45] WARNING: Disk space is running low on '/dev/sda1'. Usage: 95%.
[2024-08-21 10:15:12] ERROR: Failed to connect to database 'prod_db' at user@db.example.com. Error code: 5003.
[2024-08-21 10:16:00] INFO: User 'sara_k' updated profile. Contact: sara.k@email-provider.net.

# Hex color codes list
background-color: #FF5733;
text-color: #33FF57;
border-color: #3357FF;
`;

const App: React.FC = () => {
  const [sourceText, setSourceText] = useState<string>(initialSourceText);
  const [aiPrompt, setAiPrompt] = useState<string>('all IP addresses');
  const [regexPattern, setRegexPattern] = useState<string>('\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b');
  const [replacementString, setReplacementString] = useState<string>('---.---.---.---');
  
  const [analysisStats, setAnalysisStats] = useState<AnalysisStats | null>(null);
  const [matches, setMatches] = useState<RegexMatch[]>([]);
  const [transformedText, setTransformedText] = useState<string>('');

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSuggesting, setIsSuggesting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSuggestRegex = useCallback(async () => {
    if (!aiPrompt) {
      setError('Please enter a description for the regex pattern.');
      return;
    }
    setIsSuggesting(true);
    setError(null);
    try {
      const pattern = await suggestRegexPattern(aiPrompt);
      setRegexPattern(pattern);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      setIsSuggesting(false);
    }
  }, [aiPrompt]);

  const handleAnalysis = useCallback(() => {
    setIsLoading(true);
    setError(null);
    setAnalysisStats(null);
    setMatches([]);
    setTransformedText('');

    try {
      const startTime = performance.now();
      const regex = new RegExp(regexPattern, 'g');
      
      const currentMatches: RegexMatch[] = [];
      let match;
      while ((match = regex.exec(sourceText)) !== null) {
        currentMatches.push({ value: match[0], index: match.index });
      }

      const replacedText = sourceText.replace(regex, replacementString);
      const endTime = performance.now();

      setMatches(currentMatches);
      setTransformedText(replacedText);
      setAnalysisStats({
        matchCount: currentMatches.length,
        executionTime: endTime - startTime,
        charactersAnalyzed: sourceText.length,
      });

    } catch (err) {
      setError(err instanceof Error ? `Invalid Regex: ${err.message}` : 'An unknown error occurred during analysis.');
    } finally {
      setIsLoading(false);
    }
  }, [regexPattern, replacementString, sourceText]);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-300 font-mono flex flex-col items-center p-4 sm:p-6 md:p-8">
      <div className="w-full max-w-7xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-amber-400 animate-pulse">AI-Powered Regex Engine</h1>
          <p className="text-slate-400 mt-2">Analyze text with regex and get AI-assisted pattern suggestions.</p>
        </header>

        <main className="bg-slate-800/50 rounded-lg shadow-2xl shadow-amber-500/10 p-6 backdrop-blur-sm border border-amber-500/20 mb-8">
          <ControlPanel
            aiPrompt={aiPrompt}
            setAiPrompt={setAiPrompt}
            regexPattern={regexPattern}
            setRegexPattern={setRegexPattern}
            replacementString={replacementString}
            setReplacementString={setReplacementString}
            handleAnalysis={handleAnalysis}
            handleSuggestRegex={handleSuggestRegex}
            isLoading={isLoading}
            isSuggesting={isSuggesting}
          />
        </main>
        
        {error && <p className="text-red-400 my-4 text-center bg-red-900/50 p-3 rounded-md border border-red-500/50">{error}</p>}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <SourceEditor
                sourceText={sourceText}
                setSourceText={setSourceText}
            />
            <OutputPanels
                stats={analysisStats}
                matches={matches}
                transformedText={transformedText}
            />
        </div>

        <FooterLog />
      </div>
    </div>
  );
};

export default App;