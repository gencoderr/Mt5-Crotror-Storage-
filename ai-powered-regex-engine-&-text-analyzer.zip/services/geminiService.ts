import { GoogleGenAI, Type } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    pattern: { 
      type: Type.STRING, 
      description: 'The generated regular expression pattern string, formatted for JavaScript RegExp constructor. Do not include leading/trailing slashes or flags.' 
    },
  },
  required: ['pattern'],
};

export const suggestRegexPattern = async (description: string): Promise<string> => {
  const prompt = `
    You are an expert in regular expressions.
    Based on the following user description, generate a single, valid JavaScript regular expression pattern.
    The pattern should accurately match what the user is asking for.
    Only return the pattern string itself, without any slashes or flags.

    User description: "${description}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.2,
      },
    });

    const jsonString = response.text.trim();
    if (!jsonString) {
        throw new Error("AI returned empty response.");
    }
    
    const data = JSON.parse(jsonString);

    if (!data.pattern || typeof data.pattern !== 'string') {
        throw new Error("Invalid regex pattern format received from AI.");
    }

    return data.pattern;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get regex suggestion from AI. Please try a different description.");
  }
};
