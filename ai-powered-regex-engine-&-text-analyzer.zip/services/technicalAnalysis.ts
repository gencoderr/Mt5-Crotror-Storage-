import { StockDataPoint, SimulationResult } from '../types';

// Smoothed Moving Average (SMMA)
const calculateSMMA = (data: number[], period: number): (number | null)[] => {
  if (data.length < period) return new Array(data.length).fill(null);
  
  const smma: (number | null)[] = new Array(data.length).fill(null);
  let sum = 0;
  
  // Calculate simple moving average for the first value
  for (let i = 0; i < period; i++) {
    sum += data[i];
  }
  smma[period - 1] = sum / period;

  // Calculate the rest of the SMMA values
  for (let i = period; i < data.length; i++) {
    smma[i] = (smma[i - 1]! * (period - 1) + data[i]) / period;
  }
  
  return smma;
};

export const addAlligatorIndicator = (data: StockDataPoint[]): StockDataPoint[] => {
  const closePrices = data.map(d => d.close);

  const lipsPeriod = 5, lipsShift = 3;
  const teethPeriod = 8, teethShift = 5;
  const jawPeriod = 13, jawShift = 8;

  const lipsSMMA = calculateSMMA(closePrices, lipsPeriod);
  const teethSMMA = calculateSMMA(closePrices, teethPeriod);
  const jawSMMA = calculateSMMA(closePrices, jawPeriod);

  return data.map((point, index) => ({
    ...point,
    lips: index >= lipsShift ? lipsSMMA[index - lipsShift] : null,
    teeth: index >= teethShift ? teethSMMA[index - teethShift] : null,
    jaw: index >= jawShift ? jawSMMA[index - jawShift] : null,
  }));
};

export const addRSIIndicator = (data: StockDataPoint[], period: number = 14): StockDataPoint[] => {
    if (data.length <= period) return data.map(p => ({ ...p, rsi: null }));

    const changes = data.slice(1).map((d, i) => d.close - data[i].close);
    let avgGain = 0;
    let avgLoss = 0;
    
    // First RSI value
    for (let i = 0; i < period; i++) {
        if(changes[i] > 0) avgGain += changes[i];
        else avgLoss -= changes[i];
    }
    avgGain /= period;
    avgLoss /= period;
    
    const rsiValues: (number | null)[] = new Array(data.length).fill(null);
    let rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    rsiValues[period] = 100 - (100 / (1 + rs));

    // Subsequent RSI values
    for (let i = period; i < changes.length; i++) {
        const change = changes[i];
        const gain = change > 0 ? change : 0;
        const loss = change < 0 ? -change : 0;

        avgGain = (avgGain * (period - 1) + gain) / period;
        avgLoss = (avgLoss * (period - 1) + loss) / period;
        
        rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
        rsiValues[i + 1] = 100 - (100 / (1 + rs));
    }
    
    return data.map((point, index) => ({
        ...point,
        rsi: rsiValues[index]
    }));
};


export const runTradingSimulation = (data: StockDataPoint[]): SimulationResult => {
    const initialCapital = 10000;
    const commissionRate = 0.01; // 1%
    let capital = initialCapital;
    let shares = 0;
    let trades = 0;

    for (let i = 1; i < data.length; i++) {
        const prev = data[i - 1];
        const current = data[i];

        if (current.lips === null || current.teeth === null || prev.lips === null || prev.teeth === null) {
            continue;
        }

        // Buy signal: Lips cross above Teeth
        if (shares === 0 && prev.lips < prev.teeth && current.lips > current.teeth) {
            const price = current.open;
            const cost = price * (1 + commissionRate);
            if (capital >= cost) {
                shares = capital / cost; // Buy as many shares as possible
                capital = 0;
                trades++;
            }
        }
        // Sell signal: Lips cross below Teeth
        else if (shares > 0 && prev.lips > prev.teeth && current.lips < current.teeth) {
            const price = current.open;
            const revenue = shares * price * (1 - commissionRate);
            capital += revenue;
            shares = 0;
            trades++;
        }
    }

    // If still holding a share at the end, sell it at the last closing price
    if (shares > 0) {
        const lastPrice = data[data.length - 1].close;
        const revenue = shares * lastPrice * (1 - commissionRate);
        capital += revenue;
        shares = 0;
    }

    const finalCapital = capital;
    const profitOrLoss = finalCapital - initialCapital;
    const profitOrLossPercent = (profitOrLoss / initialCapital) * 100;

    return {
        initialCapital,
        finalCapital,
        profitOrLoss,
        profitOrLossPercent,
        trades,
    };
};