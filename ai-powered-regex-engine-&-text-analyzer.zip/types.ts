export interface AnalysisStats {
  matchCount: number;
  executionTime: number; // in ms
  charactersAnalyzed: number;
}

export interface RegexMatch {
  value: string;
  index: number;
}

export interface StockDataPoint {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  rsi?: number | null;
  lips?: number | null;
  teeth?: number | null;
  jaw?: number | null;
}

export interface SimulationResult {
  initialCapital: number;
  finalCapital: number;
  profitOrLoss: number;
  profitOrLossPercent: number;
  trades: number;
}
