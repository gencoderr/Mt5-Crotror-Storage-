import React from 'react';
import { StockDataPoint } from '../types';

interface StockChartProps {
  data1: StockDataPoint[];
  ticker1: string;
  data2: StockDataPoint[];
  ticker2: string;
}

const StockChart: React.FC<StockChartProps> = ({ data1, ticker1, data2, ticker2 }) => {
  if (data1.length < 2 || data2.length < 2) {
    return null;
  }

  const width = 800;
  const height = 400;
  const padding = 50;

  const allPrices = [
    ...data1.flatMap(d => [d.close, d.lips, d.teeth, d.jaw]),
    ...data2.map(d => d.close)
  ].filter(p => p != null) as number[];

  const minPrice = Math.min(...allPrices);
  const maxPrice = Math.max(...allPrices);
  
  const getX = (index: number, dataLength: number) => {
    return padding + (index / (dataLength - 1)) * (width - 2 * padding);
  };

  const getY = (price: number) => {
    const priceRange = (maxPrice * 1.05) - (minPrice * 0.95);
    if (priceRange === 0) return height - padding;
    return height - padding - ((price - (minPrice * 0.95)) / priceRange) * (height - 2 * padding);
  };
  
  const createPath = (data: StockDataPoint[], key: 'close' | 'lips' | 'teeth' | 'jaw') => {
    let path = '';
    let firstPoint = true;
    data.forEach((point, i) => {
      const value = point[key];
      if (value !== null && typeof value !== 'undefined') {
        const x = getX(i, data.length);
        const y = getY(value);
        if (firstPoint) {
          path += `M ${x},${y}`;
          firstPoint = false;
        } else {
          path += ` L ${x},${y}`;
        }
      }
    });
    return path;
  };
  
  const closePath1 = createPath(data1, 'close');
  const lipsPath1 = createPath(data1, 'lips');
  const teethPath1 = createPath(data1, 'teeth');
  const jawPath1 = createPath(data1, 'jaw');
  const closePath2 = createPath(data2, 'close');

  const yAxisLabels = () => {
    const labels = [];
    const numLabels = 5;
    const priceRange = maxPrice - minPrice;
    for (let i = 0; i <= numLabels; i++) {
        const price = minPrice + (priceRange / numLabels) * i;
        labels.push({ price: price.toFixed(2), y: getY(price) });
    }
    return labels;
  };
  
  const xAxisLabels = () => {
    const labels = [];
    const data = data1; // Assume both have same date range
    const numLabels = Math.min(data.length, 5);
    const step = Math.max(1, Math.floor((data.length - 1) / (numLabels > 1 ? numLabels - 1 : 1)));
    for (let i = 0; i < data.length; i += step) {
        labels.push({ date: data[i].date, x: getX(i, data.length) });
    }
    if (data.length > 1 && (data.length - 1) % step !== 0) {
        const lastLabel = labels[labels.length - 1];
        if(lastLabel.date !== data[data.length - 1].date) {
            labels.push({ date: data[data.length - 1].date, x: getX(data.length - 1, data.length) });
        }
    }
    return labels;
  };

  const legendItems = [
      { color: "#2dd4bf", label: `Close ${ticker1.toUpperCase()}` },
      { color: "#f87171", label: `Close ${ticker2.toUpperCase()}` },
      { color: "#22c55e", label: `Lips (${ticker1.toUpperCase()})` },
      { color: "#eab308", label: `Teeth (${ticker1.toUpperCase()})` },
      { color: "#3b82f6", label: `Jaw (${ticker1.toUpperCase()})` },
  ];

  return (
    <div className="bg-zinc-900/50 p-4 rounded-lg border border-zinc-700/50 mb-8 relative">
       <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto" aria-labelledby="chart-title" role="img">
        <title id="chart-title">Stock Price Chart Comparison with Alligator Indicator</title>
        
        {yAxisLabels().map(label => (
            <g key={label.price} className="text-zinc-500">
                <line x1={padding} y1={label.y} x2={width - padding} y2={label.y} stroke="currentColor" strokeWidth="0.5" strokeDasharray="2,2"/>
                <text x={padding - 10} y={label.y + 4} textAnchor="end" fill="currentColor" fontSize="12">${label.price}</text>
            </g>
        ))}
        
         {xAxisLabels().map(label => (
            <g key={label.date} className="text-zinc-500">
                 <text x={label.x} y={height - padding + 20} textAnchor="middle" fill="currentColor" fontSize="12">{label.date}</text>
            </g>
        ))}
        
        <path d={closePath1} fill="none" stroke="#2dd4bf" strokeWidth="2" />
        <path d={closePath2} fill="none" stroke="#f87171" strokeWidth="2" />
        <path d={lipsPath1} fill="none" stroke="#22c55e" strokeWidth="1.5" strokeDasharray="3,3" />
        <path d={teethPath1} fill="none" stroke="#eab308" strokeWidth="1.5" strokeDasharray="3,3" />
        <path d={jawPath1} fill="none" stroke="#3b82f6" strokeWidth="1.5" strokeDasharray="3,3" />
       </svg>
       <div className="absolute top-4 right-4 text-xs text-gray-300 bg-zinc-900/70 p-2 rounded">
           {legendItems.map(item => (
                <div key={item.label} className="flex items-center space-x-2 mt-1">
                    <span className="h-2 w-4 rounded-full" style={{ backgroundColor: item.color }}></span>
                    <span>{item.label}</span>
                </div>
            ))}
       </div>
    </div>
  );
};

export default StockChart;