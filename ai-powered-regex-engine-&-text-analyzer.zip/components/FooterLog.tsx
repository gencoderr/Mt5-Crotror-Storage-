import React from 'react';

const FooterLog: React.FC = () => {
  return (
    <footer className="mt-12 text-xs text-slate-600 border-t border-slate-800 pt-4">
      <pre className="whitespace-pre-wrap break-words">
        <p className="mb-2 text-slate-500">// System Log: R-Engine Text Analyzer Service</p>
        <p><span className="text-yellow-500">[REQUEST]</span> POST /v1/execute/regex_analysis (Payload: 12KB)</p>
        <p><span className="text-blue-500">[AUTH]</span> API key validated. User context established.</p>
        <p><span className="text-blue-500">[REGEX_ENGINE]</span> Compiling pattern with flags: 'g'.</p>
        <p><span className="text-green-500">[SUCCESS]</span> Pattern compiled in 0.8ms.</p>
        <p><span className="text-blue-500">[TEXT_SCANNER]</span> Executing match scan on source text...</p>
        <p><span className="text-blue-500">[MATCH_EXTRACTOR]</span> Iterating through matches and indices...</p>
        <p><span className="text-blue-500">[TRANSFORMER]</span> Applying replacement string to all matches...</p>
        <p><span className="text-green-500">[SIM_RESULT]</span> Analysis complete. Transformed output generated.</p>
        <p><span className="text-green-500">[RESPONSE]</span> 200 OK - Analysis ID: REX-G4H5-I6J7 (Compute: us-east-1c)</p>
      </pre>
    </footer>
  );
};

export default FooterLog;