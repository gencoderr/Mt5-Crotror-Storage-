import React from 'react';
import { AnalysisStats, RegexMatch } from '../types';

interface OutputPanelsProps {
    stats: AnalysisStats | null;
    matches: RegexMatch[];
    transformedText: string;
}

const OutputPanels: React.FC<OutputPanelsProps> = ({ stats, matches, transformedText }) => {
    if (!stats) {
        return (
            <div className="h-full flex items-center justify-center p-6 bg-slate-800/30 rounded-lg border-2 border-dashed border-slate-700">
                <p className="text-slate-500">Analysis results will be displayed here.</p>
            </div>
        );
    }
    
    return (
        <div className="space-y-6">
            {/* Stats Panel */}
            <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
                <h3 className="text-lg font-bold text-amber-400 mb-3">Analysis Stats</h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                        <p className="text-sm text-slate-400">Matches Found</p>
                        <p className="text-2xl font-semibold text-green-400">{stats.matchCount}</p>
                    </div>
                    <div>
                        <p className="text-sm text-slate-400">Characters</p>
                        <p className="text-2xl font-semibold">{stats.charactersAnalyzed.toLocaleString()}</p>
                    </div>
                    <div>
                        <p className="text-sm text-slate-400">Exec. Time</p>
                        <p className="text-2xl font-semibold">{stats.executionTime.toFixed(2)}ms</p>
                    </div>
                </div>
            </div>

            {/* Transformed Output Panel */}
            <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
                <h3 className="text-lg font-bold text-amber-400 mb-2">Transformed Output</h3>
                 <textarea
                    readOnly
                    value={transformedText}
                    className="w-full h-48 bg-slate-900/70 border border-slate-700 rounded-md p-2 text-slate-300 resize-none font-mono text-sm focus:outline-none"
                    placeholder="Output after replacement..."
                />
            </div>
            
            {/* Match List Panel */}
             <div className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50">
                <h3 className="text-lg font-bold text-amber-400 mb-2">Match List ({matches.length})</h3>
                <div className="overflow-y-auto max-h-48 bg-slate-900/70 border border-slate-700 rounded-md p-2">
                    {matches.length > 0 ? (
                        <ul className="divide-y divide-slate-700">
                           {matches.map((match, i) => (
                                <li key={i} className="p-2 flex justify-between items-center text-sm">
                                    <span className="text-green-400 break-all">{`'${match.value}'`}</span>
                                    <span className="text-slate-500 ml-4">index: {match.index}</span>
                                </li>
                           ))}
                        </ul>
                    ) : (
                        <p className="text-slate-500 text-center p-4">No matches found.</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default OutputPanels;
