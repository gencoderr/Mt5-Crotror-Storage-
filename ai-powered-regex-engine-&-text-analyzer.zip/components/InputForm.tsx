import React from 'react';

interface ControlPanelProps {
  aiPrompt: string;
  setAiPrompt: (value: string) => void;
  regexPattern: string;
  setRegexPattern: (value: string) => void;
  replacementString: string;
  setReplacementString: (value: string) => void;
  handleAnalysis: () => void;
  handleSuggestRegex: () => void;
  isLoading: boolean;
  isSuggesting: boolean;
}

const LoadingSpinner: React.FC = () => (
    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
);

const ControlPanel: React.FC<ControlPanelProps> = ({ 
  aiPrompt, setAiPrompt, regexPattern, setRegexPattern, replacementString, setReplacementString, handleAnalysis, handleSuggestRegex, isLoading, isSuggesting
}) => {
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleAnalysis();
  };
    
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="aiPrompt" className="block text-sm font-medium text-slate-400 mb-2">1. Get an AI-Powered Regex Suggestion</label>
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            id="aiPrompt"
            type="text"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="e.g., all hex color codes"
            className="flex-grow bg-slate-900 border border-slate-600 rounded-md py-2 px-4 text-amber-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500"
          />
          <button
            type="button"
            onClick={handleSuggestRegex}
            disabled={isSuggesting || isLoading}
            className="flex items-center justify-center px-4 py-2 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition duration-200"
          >
            {isSuggesting && <LoadingSpinner />}
            {isSuggesting ? 'Suggesting...' : 'Suggest Pattern'}
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="regexPattern" className="block text-sm font-medium text-slate-400 mb-2">2. Enter Regex Pattern</label>
          <input
            id="regexPattern"
            type="text"
            value={regexPattern}
            onChange={(e) => setRegexPattern(e.target.value)}
            placeholder="[a-zA-Z]+"
            className="w-full bg-slate-900 border border-slate-600 rounded-md py-2 px-4 text-amber-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500"
          />
        </div>
        <div>
          <label htmlFor="replacementString" className="block text-sm font-medium text-slate-400 mb-2">3. Enter Replacement String (optional)</label>
          <input
            id="replacementString"
            type="text"
            value={replacementString}
            onChange={(e) => setReplacementString(e.target.value)}
            placeholder="[REPLACED]"
            className="w-full bg-slate-900 border border-slate-600 rounded-md py-2 px-4 text-amber-300 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none transition duration-200 placeholder-slate-500"
          />
        </div>
      </div>

      <div className="flex items-center justify-center pt-2">
        <button
          type="submit"
          disabled={isLoading || !regexPattern}
          className="w-full sm:w-auto flex items-center justify-center px-8 py-3 bg-amber-600 text-slate-900 font-bold rounded-md hover:bg-amber-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition duration-200 text-lg"
        >
          {isLoading && <LoadingSpinner />}
          {isLoading ? 'Analyzing...' : 'Execute Analysis'}
        </button>
      </div>
    </form>
  );
};

export default ControlPanel;