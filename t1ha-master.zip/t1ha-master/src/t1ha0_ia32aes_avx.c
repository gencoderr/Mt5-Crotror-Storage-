#ifndef T1HA0_DISABLED
#define T1HA_IA32AES_NAME t1ha0_ia32aes_avx
#include "t1ha0_ia32aes_a.h"
#endif /* T1HA0_DISABLED */
